'''
typspel ~ begonnen op 15/05/2018 om 19:22
'''
from tkinter import *
import random, time



#window generatie

class main(object):
    def __init__(self, infow):
        (self.tk, self.canvas) = infow
        
        with open('woorden.txt', 'r') as infile:
            self.woorden = [i.strip() for i in infile.readlines()]
        print(self.woorden)
        
        self.foto = PhotoImage(file='bg1.gif')
        self.veld()
        self.active = []
        self.wrds = []
        self.gameOver = False
        self.score = 0
        self.scoreBox = self.canvas.create_text(1, 1, font=('Helvetica', 9), \
                        anchor=NW, text='SCORE: %s' %(self.score))

        self.entry = Entry(self.tk, width=70)
        self.entry.pack()
        tk.update()

        self.t1 = time.time() + random.random()*5
        
        self.canvas.bind_all('<Return>', self.lees)

    def veld(self):
        #background
        self.canvas.create_image(0, 0, anchor=NW, image=self.foto)
        for i in range(10):
            self.canvas.create_rectangle(450+5*(i%2 == 0), i*20, 455+5*\
                (i%2 == 0), (i+1)*20, fill='#000000')
              
        self.tk.update()
        return

    def newword(self):
        #zorgt voor een nieuw woord (twee dezelfde woorden tegelijk gaat niet!)
        wrd = random.choice(self.woorden)
        if wrd not in self.wrds:
            self.active.append(woord(wrd, self.canvas))
            self.wrds.append(wrd)
            
        self.t1 += random.random()*3 + 0.5

    def moves(self):
        #zorgt dat elk woord naar rechts beweegt
        for i in self.active:
            if i.move():
                self.gameOver = True
                
                
        if time.time() - self.t1 > 0:
            self.newword()
        return

    def lees(self, evt):
        #leest alle geschreven text in
        invoer = self.entry.get().strip()
        if invoer in self.wrds:
            id = self.wrds.index(invoer)
            self.active[id].verdwijn()
            del self.active[id]
            del self.wrds[id]

            self.score += 1
            self.canvas.itemconfig(self.scoreBox, text='SCORE: %s' %(self.score))


        #variabele voor testing
        if invoer == '404':
            self.gameOver = True
            
            
        self.entry.delete(0, END)

    
    

class woord(object):
    def __init__(self, wrd, canvas):
        self.wrd = wrd
        self.x = -10
        self.y = random.randint(25,150)
        self.vx = 1 + (random.randint(1, 10)> 7)
        self.canvas = canvas
        self.wordbox = self.canvas.create_text(self.x, self.y, anchor=NE, \
                    font=('Helvetica', 12), text=self.wrd, fill='#000000')

        
    def move(self):
        self.x += self.vx
        self.canvas.move(self.wordbox, self.vx, 0)
        if self.x > 455:
            self.canvas.itemconfig(self.wordbox, fill='#ff0000')
            self.canvas.update()
            return True
        return False
    

    def verdwijn(self):
        self.canvas.delete(self.wordbox)
        
    




tk = Tk()
tk.resizable(0,0)
tk.wm_attributes('-topmost', 1)

canvas = Canvas(tk, height=200, width=500, bd=0, highlightthickness=0)
canvas.pack()

w = main((tk, canvas))

while not w.gameOver:
    tk.update()
    tk.update_idletasks()
    w.moves()
    time.sleep(1/20)

time.sleep(2)
tk.destroy()



